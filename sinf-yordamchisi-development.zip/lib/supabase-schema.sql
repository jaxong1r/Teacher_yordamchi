-- Sinf Yordamchisi: Supabase-ready schema
-- Apply in Supabase SQL editor after creating a project.
create type public.app_role as enum ('teacher', 'klasskom');
create type public.attendance_status as enum ('present', 'absent', 'excused');

create table public.class_settings (
  id uuid primary key default gen_random_uuid(),
  name text not null default '9-B sinf',
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text not null,
  last_name text not null,
  username text unique not null,
  role public.app_role not null,
  class_id uuid references public.class_settings(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.students (
  id bigint generated always as identity primary key,
  class_id uuid not null references public.class_settings(id) on delete cascade,
  first_name text not null,
  last_name text not null,
  created_at timestamptz not null default now()
);

create table public.attendance (
  id bigint generated always as identity primary key,
  student_id bigint not null references public.students(id) on delete cascade,
  date date not null,
  status public.attendance_status not null,
  updated_by uuid not null references public.profiles(id),
  updated_at timestamptz not null default now(),
  unique(student_id, date)
);

create table public.duty_schedules (
  id bigint generated always as identity primary key,
  student_id bigint not null references public.students(id) on delete cascade,
  date date not null,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.payments (
  id bigint generated always as identity primary key,
  student_id bigint not null references public.students(id) on delete cascade,
  period date not null,
  expected_amount integer not null check (expected_amount >= 0),
  paid_amount integer not null default 0 check (paid_amount >= 0 and paid_amount <= expected_amount),
  updated_at timestamptz not null default now(),
  unique(student_id, period)
);

alter table public.payments enable row level security;
create policy "Only klasskom can read payments" on public.payments for select using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'klasskom')
);
create policy "Only klasskom can write payments" on public.payments for all using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'klasskom')
) with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'klasskom')
);

-- Add equivalent class-scoped policies for students, attendance, and duties.
-- The application data layer is intentionally provider-agnostic until credentials are added.

-- Expected environment variables (never hardcode values):
-- NEXT_PUBLIC_SUPABASE_URL
-- NEXT_PUBLIC_SUPABASE_ANON_KEY
