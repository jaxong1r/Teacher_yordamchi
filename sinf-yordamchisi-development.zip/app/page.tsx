import ClassroomDashboard from '@/components/classroom-dashboard'

export default function Page() {
  return <ClassroomDashboard />
}
